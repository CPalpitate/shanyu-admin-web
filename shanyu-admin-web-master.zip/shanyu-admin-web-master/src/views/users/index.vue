<template>
  <div class="users-container p-6">
    <h1 class="text-2xl font-bold mb-4">用户管理</h1>
    <p class="text-gray-600">用户管理页面开发中...</p>
  </div>
</template>

<script setup lang="ts">
// 用户管理页面
</script> 